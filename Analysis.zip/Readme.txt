I use skype and this is my skype name live:.cid.3285eff780932fb9
and my eamil is makarov0114@outlook.com


https://moralis.io/how-to-program-token-swaps-with-1inch-plugin/
